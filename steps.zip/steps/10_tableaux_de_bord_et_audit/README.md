# Étape 10_tableaux_de_bord_et_audit

Lis d’abord `../PROMPT_GENERAL.md` et `../etat.md`. Exécute les prompts de ce dossier dans l’ordre. Après chaque prompt, crée un rapport `rapport_YYYY-MM-DD_HHMM_<slug>.md` dans ce dossier. Ne passe pas à l’étape suivante sans rapport ou décision de report documentée.
